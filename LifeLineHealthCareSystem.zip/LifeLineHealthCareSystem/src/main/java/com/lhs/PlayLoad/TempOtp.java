package com.lhs.PlayLoad;

public class TempOtp {
	private int otp;

	public int getOtp() {
		return otp;
	}

	public void setOtp(int otp) {
		this.otp = otp;
	}

}
